% Delay between two correlated signals
% Ejemplo tomado de:
% http://www.mathworks.com/help/signal/ref/xcorr.html

% Two sensors at different locations measure vibrations caused by a car as
% it crosses a bridge. Load the signals and the sample rate, Fs = 11025 Hz. 
% Create time vectors and plot the signals. The signal from Sensor 2 
% arrives at an earlier time than the signal from Sensor 1.

clear, clc, close all

load sensorData

t1 = (0:length(s1)-1)/Fs;
t2 = (0:length(s2)-1)/Fs;

figure
subplot(2,1,1)
plot(t1,s1)
title('s_1')

subplot(2,1,2)
plot(t2,s2)
title('s_2')
xlabel('Time (s)')

% The cross-correlation of the two measurements is maximum at a lag equal 
% to the delay. Plot the cross-correlation. Express the delay as a number 
% of samples and in seconds.
[acor,lag] = xcorr(s2, s1);

[~,I] = max(abs(acor));
lagDiff = lag(I)
timeDiff = lagDiff/Fs

figure
plot(lag,acor)
set(gca, 'XTick', sort([-3000:1000:3000 lagDiff]));
title('Cross correlation function')

% Align the two signals and replot them.
s1al = s1(-lagDiff:end);
t1al = (0:length(s1al)-1)/Fs;

figure
subplot(2,1,1)
plot(t1al,s1al)
title('s_1, aligned')

subplot(2,1,2)
plot(t2,s2)
title('s_2')
xlabel('Time (s)')
